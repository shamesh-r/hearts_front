export const selectPlayer = (state) => state.player
export const selectHand = (state) => state.player.hand
export const selectSeatIndex = (state) => state.player.seatIndex
export const selectConnectionStatus = (state) => state.player.connected
