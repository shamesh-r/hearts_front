class Responsive {
  static isMobile() {
    return window.innerWidth < 768;
  }
}